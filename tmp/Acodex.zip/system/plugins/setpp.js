import { sendText, getBuff, userManager } from '../helper.js'

/**
 * @param {import('../types/plugin.js').HandlerParams} params
 */
 
async function handler({ m, q, jid, sock }) {
if (!
userManager.trustedJids.has(m.senderId))
return 

   const img = m.q ? m.q : m

   if (!img) {
      return await sendText(
         jid,
         'mana gambar nya',
         m
      )
   }

   try {
      
      const buffer = await getBuff(img)

    
      await sock.updateProfilePicture(sock.user.id, buffer)

      await sendText(sock, jid, '✅ Foto profil bot berhasil diubah.', m)
   } catch (err) {
      console.error(err)
      await sendText(sock, jid, ' Gagal mengubah foto profil bot.', m)
   }
}

handler.pluginName = 'ganti pp bot'
handler.command = ['setpp']
handler.category = ['developer']
handler.deskripsi = 'Ubah foto profil bot dengan kirim atau reply gambar.'
handler.meta = {
fileName: 'setppbot.js',
version: '1',
author: 'Ky'
}

export default handler